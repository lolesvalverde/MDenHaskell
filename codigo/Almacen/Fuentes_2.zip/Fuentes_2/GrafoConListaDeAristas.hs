-- Sólo grafos no dirigidos sin pesos

module GrafoConListaDeAristas
    ( Grafo
    , creaGrafo  
    , vertices      
    , aristas    
    , adyacentes 
    , aristaEn   
    ) where

import Data.List (sort)

data Grafo a = G [a] [(a,a)]
  deriving (Show, Eq)

creaGrafo :: Ord a => [a] -> [(a,a)] -> Grafo a
creaGrafo vs as =
  G (sort vs) (sort [parOrdenado a | a <- as])

parOrdenado :: Ord a => (a,a) -> (a,a)
parOrdenado (x,y) | x <= y    = (x,y)
                  | otherwise = (y,x)

-- λ> ejGrafo
-- G [1,2,3,4,5] [(1,2),(1,3),(1,5),(2,4),(2,5),(3,4),(3,5),(4,5)]
ejGrafo :: Grafo Int 
ejGrafo = creaGrafo [1..5] [(1,2),(1,3),(1,5),
                            (2,4),(2,5),
                            (3,4),(3,5),
                            (4,5)]

-- vertices ejGrafo  ==  [1,2,3,4,5]
vertices :: Grafo a -> [a]
vertices (G vs _) = vs

-- λ> aristas ejGrafo 
-- [(1,2),(1,3),(1,5),(2,4),(2,5),(3,4),(3,5),(4,5)]
aristas :: Grafo a -> [(a,a)]
aristas (G _ as) = as

-- adyacentes ejGrafo 4  ==  [2,3,5]
adyacentes :: Eq a => Grafo a -> a -> [a]
adyacentes (G _ as) v =
  [u | (u,x) <- as, x == v] ++
  [u | (x,u) <- as, x == v] 

-- aristaEn ejGrafo (1,3)  ==  True
-- aristaEn ejGrafo (1,4)  ==  False
-- aristaEn ejGrafo (3,1)  ==  True
aristaEn :: Ord a => Grafo a -> (a,a) -> Bool
aristaEn (G _ as) a = 
  parOrdenado a `elem` as


