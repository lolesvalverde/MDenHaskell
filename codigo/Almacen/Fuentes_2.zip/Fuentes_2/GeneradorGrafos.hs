{-# LANGUAGE FlexibleInstances #-}

module GeneradorGrafos where

import Test.QuickCheck
import GrafoConListaDeAristas

-- generaGrafo es un generador de grafos. Por ejemplo,
--    λ> sample generaGrafo
--    G [1,2,3,4,5] [(1,1),(1,3),(2,2),(2,3),(3,4),(3,5),(4,4)]
--    G [1,2] [(1,2),(2,2)]
--    G [1,2] [(1,1),(2,2)]
--    G [1,2,3] [(1,2),(1,3),(2,2)]
--    G [1,2,3,4] [(1,3),(2,4),(3,3),(3,4)]
--    G [1,2,3,4] [(1,3),(2,4),(3,3)]
--    G [1,2,3,4,5,6] [(1,5),(2,2),(2,4),(2,5),(3,4),(3,5),(4,4),(5,6),(6,6)]
--    G [1,2,3,4,5] [(1,4),(1,5),(2,5),(4,5),(5,5)]
generaGrafo :: Gen (Grafo Int)
generaGrafo = do
  n <- choose (1,10)
  as <- sublistOf [(x,y) | x <- [1..n], y <- [x..n]]
  return (creaGrafo [1..n] as)

-- Los grafos está contenido en la clase de los objetos generables
-- aleatoriamente. 
instance Arbitrary (Grafo Int) where
    arbitrary = generaGrafo
