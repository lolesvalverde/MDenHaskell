module GrafoConMatrizDeAdyacencia
    ( Grafo
    , Vertice
    , creaGrafo  -- (Vertice,Vertice) -> [(Vertice,Vertice)] -> Grafo
    , adyacentes -- Grafo -> Vertice -> [Vertice]
    , nodos      -- Grafo -> [Vertice]
    , aristas    -- Grafo -> [(Vertice,Vertice)]
    , aristaEn   -- Grafo -> (Vertice,Vertice) -> Bool
    ) where

import Data.Array

type Vertice = Int

data Grafo = G (Array (Vertice,Vertice) Int)
             deriving (Eq, Show)

creaGrafo :: (Vertice,Vertice) -> [(Vertice,Vertice)] -> Grafo 
creaGrafo cs@(l,u) as 
    = G (matrizVacia // 
          ([((x1,x2),1) | (x1,x2) <- as] ++
           [((x2,x1),1) | (x1,x2) <- as, x1 /= x2]))
      where
      matrizVacia = array ((l,l),(u,u)) 
                          [((x1,x2),0) | x1 <- range cs, 
                                         x2 <- range cs]

-- λ> ejGrafo
-- G (array ((1,1),(5,5))
--          [((1,1),0),((1,2),1),((1,3),1),((1,4),0),((1,5),1),
--           ((2,1),1),((2,2),0),((2,3),0),((2,4),1),((2,5),1),
--           ((3,1),1),((3,2),0),((3,3),0),((3,4),1),((3,5),1),
--           ((4,1),0),((4,2),1),((4,3),1),((4,4),0),((4,5),1),
--           ((5,1),1),((5,2),1),((5,3),1),((5,4),1),((5,5),0)])
-- λ> let (G g) = ejGrafo
-- λ> elems g
-- [0,1,1,0,1,
--  1,0,0,1,1,
--  1,0,0,1,1,
--  0,1,1,0,1,
--  1,1,1,1,0]
ejGrafo :: Grafo 
ejGrafo = creaGrafo (1,5) [(1,2),(1,3),(1,5),
                           (2,4),(2,5),
                           (3,4),(3,5),
                           (4,5)]

-- nodos ejGrafo == [1,2,3,4,5]
nodos :: Grafo -> [Vertice]
nodos (G g) = range (l,u) 
    where ((l,_),(u,_)) = bounds g

-- adyacentes ejGrafo 3  ==  [1,4,5]
adyacentes :: Grafo -> Vertice -> [Vertice]
adyacentes (G g) v = 
    [v' | v' <- nodos (G g), g!(v,v') == 1]

-- aristaEn ejGrafoD (4,1)  ==  False
aristaEn :: Grafo -> (Vertice,Vertice) -> Bool
aristaEn (G g) (x,y) = g!(x,y) == 1

-- ghci> aristas ejGrafo
-- [(1,2),(1,3),(1,5),(2,1),(2,4),(2,5),(3,1),(3,4),(3,5),
--  (4,2),(4,3),(4,5),(5,1),(5,2),(5,3),(5,4)]
aristas :: Grafo -> [(Vertice,Vertice)]
aristas g =
  [(v1,v2) | v1 <- nodos g, v2 <- nodos g, aristaEn g (v1,v2)]
