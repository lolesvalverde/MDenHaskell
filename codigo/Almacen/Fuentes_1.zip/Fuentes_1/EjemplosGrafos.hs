module EjemplosGrafos ( grafoCiclo
                      , grafoAmistad
                      , completo
                      , bipartitoCompleto
                      , grafoEstrella
                      , grafoRueda
                      , grafoCirculante
                      , grafoPetersenGen
                      , grafoThomson
                      , grafoPetersen
                      , grafoMoebiusCantor
                      ) where

import GrafoConVectorDeAdyacencia
-- import GrafoConMatrizDeAdyacencia 

import Data.List

g1, g2, g3, g4, g5, g6, g7, g8, g9, g10, g11, g12 :: Grafo 
g1  = creaGrafo (1,5) [(1,2),(1,3),(1,5),
                       (2,4),(2,5),
                       (3,4),(3,5),
                       (4,5)]
g2  = creaGrafo (1,5) [(1,2),(1,3),(1,5),
                       (2,4),(2,5),
                       (4,3),(4,5)]
g3  = creaGrafo (1,3) [(1,2),(2,2),(3,1),(3,2)]
g4  = creaGrafo (1,4) [(1,2),(2,1)]
g5  = creaGrafo (1,1) [(1,1)]
g6  = creaGrafo (1,4) [(1,3),(3,1),(3,3),(4,2)]
g7  = creaGrafo (1,4) [(1,3)]
g8  = creaGrafo (1,5) [(1,1),(1,2),(1,3),(2,4),(3,1),
                       (4,1),(4,2),(4,4),(4,5)]
g9  = creaGrafo (1,5) [(4,1),(4,3),(5,1)]
g10 = creaGrafo (1,3) [(1,2),(1,3),(2,3),(3,3)]
g11 = creaGrafo (1,3) [(1,2),(1,3),(2,3),(3,3)]
g12 = creaGrafo (1,4) [(1,1),(1,2),(3,3)]


-- λ> grafoCiclo 5
-- G (array (0,4) [(0,[4,1]),(1,[0,2]),(2,[1,3]),(3,[2,4]),(4,[3,0])])
grafoCiclo :: Int -> Grafo 
grafoCiclo n =
    creaGrafo (0,n-1) ([(x,x+1) | x <- [0..n-2]] ++ [(n-1,0)])

-- λ> grafoAmistad 2
-- G (array (0,4) [(0,[1,2,3,4]),
--                 (1,[0,2]),(2,[0,1]),(3,[0,4]),(4,[0,3])])
-- λ> grafoAmistad 3
-- G (array (0,6) [(0,[1,2,3,4,5,6]),
--                 (1,[0,2]),(2,[0,1]),(3,[0,4]),(4,[0,3]),(5,[0,6]),(6,[0,5])])
grafoAmistad :: Int -> Grafo 
grafoAmistad n =
  creaGrafo (0,2*n)
            ([(0,a) | a <- [1..2*n]] ++
             [(a,b) | (a,b) <-zip [1,3..2*n] [2,4..2*n]])

-- λ> completo 4
-- G (array (0,3) [(0,[1,2,3]),(1,[2,3,0]),(2,[3,0,1]),(3,[0,1,2])])
completo :: Int -> Grafo 
completo n =
    creaGrafo (0,n-1)
              [(a,b) | a <- [0..n-1], b <- [0..a-1]]

-- λ> bipartitoCompleto 2 3
-- G (array (0,4) [(0,[2,3,4]),(1,[2,3,4]),(2,[0,1]),(3,[0,1]),(4,[0,1])])
bipartitoCompleto :: Int -> Int -> Grafo 
bipartitoCompleto n m =
  creaGrafo (0,n+m-1)
            [(a,b) | a <- [0..n-1], b <- [n..n+m-1]]

-- λ> grafoEstrella 5
-- G (array (0,5) [(0,[1,2,3,4,5]),(1,[0]),(2,[0]),(3,[0]),(4,[0]),(5,[0])])
grafoEstrella :: Int -> Grafo  
grafoEstrella = bipartitoCompleto 1 

-- λ> grafoRueda 6
-- G (array (0,5) [(0,[1,2,3,4,5]),(1,[0,2,5]),(2,[0,1,3]),
--                 (3,[0,2,4]),(4,[0,3,5]),(5,[0,1,4])])
grafoRueda :: Int -> Grafo 
grafoRueda n =
  creaGrafo (0,n-1)
            ([(0,a) | a <- [1..n-1]] ++
             [(a,b) | (a,b) <- zip (1:[1..n-2]) (2:(n-1):[3..n-1])])

-- λ> grafoCirculante 6 [1,2]
-- G (array (0,5) [(0,[1,2,4,5]),(1,[0,2,3,5]),(2,[0,1,3,4]),
--                 (3,[1,2,4,5]),(4,[0,2,3,5]),(5,[0,1,3,4])])
grafoCirculante :: Int -> [Int] -> Grafo 
grafoCirculante n ss =
  creaGrafo (0,n-1)
            [(a,b) | a <- [0..n-1]
                   , b <- sort (auxCir a ss n)
                   , a < b]
  where auxCir :: Int -> [Int] -> Int -> [Int]
        auxCir v ss n =
          concat [[(v+s) `mod` n, (v-s) `mod` n] | s <- ss]

-- λ> grafoPetersenGen 4 2
-- G (array (0,7) [(0,[2,2,4]),(1,[3,3,5]),(2,[0,0,6]),(3,[1,1,7]),
--                 (4,[0,7,5]),(5,[1,4,6]),(6,[2,5,7]),(7,[3,6,4])])
grafoPetersenGen :: Int -> Int -> Grafo 
grafoPetersenGen n k =
  creaGrafo (0,2*n-1)
            ((filter p (aristas (grafoCirculante n [k]))) ++
             [(x,x+n) | x <- [0..(n-1)]] ++
             [(x,x+1) | x <- [n..(2*(n-1))]] ++ [(2*n-1,n)])
  where p (a,b) = a < b

-- λ> grafoThomson
-- G (array (0,5) [(0,[3,4,5]),(1,[3,4,5]),(2,[3,4,5]),
--                 (3,[0,1,2]),(4,[0,1,2]),(5,[0,1,2])])
grafoThomson :: Grafo 
grafoThomson = bipartitoCompleto 3 3

-- λ> grafoPetersen
-- G (array (0,9) [(0,[2,3,5]),(1,[3,4,6]),(2,[0,4,7]),(3,[0,1,8]),(4,[1,2,9]),
--                 (5,[0,9,6]),(6,[1,5,7]),(7,[2,6,8]),(8,[3,7,9]),(9,[4,8,5])])
grafoPetersen :: Grafo 
grafoPetersen = grafoPetersenGen 5 2

-- λ> grafoMoebiusCantor
-- G (array (0,15) [( 0,[3, 5, 8]),( 1,[4, 6, 9]),( 2,[5, 7,10]),( 3,[0, 6,11]),
--                  ( 4,[1, 7,12]),( 5,[0, 2,13]),( 6,[1, 3,14]),( 7,[2, 4,15]),
--                  ( 8,[0,15, 9]),( 9,[1, 8,10]),(10,[2, 9,11]),(11,[3,10,12]),
--                  (12,[4,11,13]),(13,[5,12,14]),(14,[6,13,15]),(15,[7,14,8])])
grafoMoebiusCantor :: Grafo 
grafoMoebiusCantor = grafoPetersenGen 8 3
