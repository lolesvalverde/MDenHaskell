{-# LANGUAGE FlexibleInstances #-}

module GeneradorGrafos where

import Test.QuickCheck
import GrafoConVectorDeAdyacencia
-- import GrafoConMatrizDeAdyacencia

-- generaGrafo es un generador de grafos. Por ejemplo,
--    λ> sample generaGrafo
--    G (array (1,2) [(1,[1,2]),(2,[1,2])])
--    G (array (1,4) [(1,[2,3]),(2,[1,4]),(3,[1,4]),(4,[2,3])])
--    G (array (1,5) [(1,[2,4]),(2,[1]),(3,[3]),(4,[1]),(5,[])])
--    G (array (1,5) [(1,[2,4]),(2,[1,2,5]),(3,[4]),(4,[1,3]),(5,[2])])
--    G (array (1,4) [(1,[2,3]),(2,[1]),(3,[1,3]),(4,[4])])
--    G (array (1,4) [(1,[3,4]),(2,[]),(3,[1,3]),(4,[1,4])])
--    G (array (1,3) [(1,[1,2,3]),(2,[1,2,3]),(3,[1,2,3])])
--    ...
generaGrafo :: Gen Grafo
generaGrafo = do
  n <- choose (1,10)
  as <- sublistOf [(x,y) | x <- [1..n], y <- [x..n]]
  return (creaGrafo (1,n) as)

-- Los grafos está contenido en la clase de los objetos generables
-- aleatoriamente. 
instance Arbitrary Grafo where
    arbitrary = generaGrafo

