module DefinicionesYPropiedades
  ( entorno
  , grado
  , sonIncidentes
  , lazo
  , esAislado
  , esRegular
  , valenciaMin
  , valenciaMax
  ) where

import Data.List (intersect)
import Test.QuickCheck 

import GrafoConVectorDeAdyacencia
-- import GrafoConMatrizDeAdyacencia 
import EjemplosGrafos
import GeneradorGrafos

-- entorno (grafoEstrella 5) 0  ==  [1,2,3,4,5]
-- entorno (grafoEstrella 5) 1  ==  [0]
entorno :: Grafo -> Vertice -> [Vertice]
entorno g v = [u | u <- nodos g, v `elem` adyacentes g u]

sonIncidentes :: Eq a => (a,a) -> (a,a) -> Bool
sonIncidentes (u1,u2) (v1,v2) =
   not (null ([u1,u2] `intersect` [v1,v2]))

lazo :: Eq a => (a,a) -> Bool
lazo (u,v) = u == v

-- grado (grafoEstrella 5) 0 ==  5
-- grado (grafoEstrella 5) 1 ==  1
grado :: Grafo -> Vertice -> Int
grado g v = length (entorno g v)

-- esAislado (creaGrafo (1,3) [(3,1)]) 2  ==  True
-- esAislado (creaGrafo (1,3) [(3,1)]) 3  ==  False
-- esAislado (creaGrafo (1,3) [(3,1)]) 1  ==  False
-- esAislado (grafoEstrella 5)         0 ==  False
-- esAislado (bipartitoCompleto 1 5)   4 ==  False
esAislado :: Grafo -> Vertice -> Bool
esAislado g v = grado g v == 0

-- esRegular (grafoCiclo 5)           ==  True
-- esRegular (bipartitoCompleto 2 2)  ==  True
-- esRegular (grafoEstrella 4)        ==  False
-- esRegular (grafoRueda 7)           ==  False
esRegular :: Grafo -> Bool
esRegular g = all (==x) xs
  where (x:xs) = [grado g v | v <- nodos g]

-- valenciaMin (grafoEstrella 6) == 1
-- valenciaMin (grafoCiclo 4)    == 2
-- valenciaMin grafoPetersen     == 3
-- valenciaMin ejGrafoD          == 0
valenciaMin :: Grafo -> Int
valenciaMin g = minimum [grado g v | v <- nodos g]

-- valenciaMax (grafoEstrella 6) == 6
-- valenciaMax (grafoCiclo 4)    == 2
-- valenciaMax grafoPetersen     == 3
-- valenciaMax ejGrafoD          == 3
valenciaMax :: Grafo -> Int
valenciaMax g = maximum [grado g v | v <- nodos g]

prop_valencia :: Grafo -> Bool
prop_valencia g =
  valenciaMin g <= valenciaMax g

-- La comprobación es
--   λ> quickCheck prop_valencia
--   +++ OK, passed 100 tests.
