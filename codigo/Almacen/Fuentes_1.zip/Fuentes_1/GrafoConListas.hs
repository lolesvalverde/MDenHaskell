-- Sólo grafos no dirigidos sin pesos

module GrafoConListas
    ( Grafo
    , Vertice
    , creaGrafo  -- (Vertice,Vertice) -> [(Vertice,Vertice)] -> Grafo
    , adyacentes -- Grafo -> Vertice -> [Vertice]
    , nodos      -- Grafo -> [Vertice]
    , aristas    -- Grafo -> [(Vertice,Vertice)]
    , aristaEn   -- Grafo -> (Vertice,Vertice) -> Bool
    ) where

import Data.List (sort)

data Grafo v = G [v] [(v,v)]
               deriving (Eq, Show)

creaGrafo :: [v] -> [(v,v)] -> Grafo v
creaGrafo vs as = G vs as

-- ghci> ejGrafo
-- G (array (1,5) [(1,[2,3,5]),
--                 (2,[1,4,5]),
--                 (3,[1,4,5]),
--                 (4,[2,3,5]),
--                 (5,[1,2,3,4])])
ejGrafo :: Grafo Int 
ejGrafo = creaGrafo [1..5] [(1,2),(1,3),(1,5),
                            (2,4),(2,5),
                            (3,4),(3,5),
                            (4,5)]

{-
-- nodos ejGrafo  ==  [1,2,3,4,5]
nodos :: Grafo -> [Vertice]
nodos (G g) = indices g

-- adyacentes ejGrafo 4  ==  [2,3,5]
adyacentes :: Grafo -> Vertice -> [Vertice]
adyacentes (G g) v = g!v

-- aristaEn ejGrafo (1,3)  ==  True
-- aristaEn ejGrafo (1,4)  ==  False
aristaEn :: Grafo -> (Vertice,Vertice) -> Bool
aristaEn g (x,y) = y `elem` adyacentes g x

-- λ> aristas ejGrafo
-- [(1,2),(1,3),(1,5),(2,1),(2,4),(2,5),(3,1),(3,4),(3,5),
--  (4,2),(4,3),(4,5),(5,1),(5,2),(5,3),(5,4)]
aristas :: Grafo -> [(Vertice,Vertice)]
aristas (G g) = [(v1,v2) | v1 <- nodos (G g), v2 <- g!v1] 
-}
